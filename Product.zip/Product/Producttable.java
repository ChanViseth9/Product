import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class Producttable {

    public static void main(String[] args) throws Exception {
        String url = "jdbc:mysql://localhost:3306/E6ProductMidterm";
        String username = "your_username";
        String password = "your_password";

        Connection connection = DriverManager.getConnection(url, username, password);
        Statement statement = connection.createStatement();

        String sql = "CREATE TABLE Product (id INT PRIMARY KEY, name VARCHAR(255), price_per_unit DOUBLE, active_for_sell BOOLEAN)";
        statement.execute(sql);

        System.out.println("Product table created successfully!");

        statement.close();
        connection.close();
    }
}